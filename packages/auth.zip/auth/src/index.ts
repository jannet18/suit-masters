import { authRoute } from "./routes/verify";
import { Hono } from "hono";
import { logger } from "hono/logger";
import { serveStatic } from "hono/serve-static";
import orderRoutes from "@repo/orders";
const app = new Hono();

// 2. The Middleware (Verifies the Token and finds the local DB User)
app.use("*", logger());

const apiRoutes = app
  .basePath("/api")
  .route("/orders", orderRoutes)
  .route("/", authRoute);
app.get("*", serveStatic({ path: "./public/index.html" }));

export default app;
